--Q1.1

use Training_24Oct18_Pune

CREATE table  student_164307
(
 RollNo INT identity(1001,1),
 StudentName varchar (20),
 Stream varchar (20)
 );


INSERT INTO student_164307
VALUES
('Anil', 'Science'),
('Madhavi', 'Arts'),
('Rajeev', 'Science'),
('Shalaka', 'Commerce'),
('Jivika', 'Arts');

--Q1.2

CREATE table marks1_164307
(
 RollNo int,
 subject1 int,
 subject2 int,
 subject3 int,
 subject4 int,
 subject5 int,
 Total int
 );


 INSERT INTO marks1_164307
 VALUES
 (1002,35,40,35,45,37,192),
 (1001,45,40,38,30,32,185),
 (1003,48,40,49,42,42,221),
 (1004,40,35,38,48,38,199);

  SELECT * FROM marks1_164307;

  alter table marks1_164307 add ('subject1' + 'subject2' + 'subject3' + 'subject4' + 'subject5');


  --Q2.1 DISPALY RollNo,StudentName amd stream for all the students
     select * from student_164307;

	 -- output:

			1001	Anil	Science
			1002	Madhavi	Arts
			1003	Rajeev	Science
			1004	Shalaka	Commerce
			1005	Jivika	Arts

  --Q2.2 DISPALY marks of student whose rollno= 1004
     select * from marks1_164307
	 where rollNo=1004;
	 
	 -- output:

	  1004	40	35	38	48	38
	   

  --Q2.3 Display name and marks of student whose name  contains letter "h" anywhere in the name
   select s.studentName,m.subject1,m.subject2,m.subject3,m.subject4,m.subject5
    from student_164307  s inner join marks1_164307 m
	on s.RollNo=m.RollNo
	where s.studentName like '%h%'; 


	--output:   

		Madhavi	35	40	35	45	37
		Shalaka	40	35	38	48	38


--Q2.4 stored procedure to add a record in marks table.

   CREATE procedure record5_164307 @RollNo int,@Subject1 int,@Subject2 int,@Subject3 int,@Subject4 int,@Subject5 int,@Total int
   AS
   BEGIN
     insert into record5_164307  values (@RollNo,@Subject1,@Subject2,@Subject3,@Subject4,@Subject5,@Total);
   END

    execute record5_164307  1005,45,40,35,40,48,198;

	select * from marks1_164307;

	sp_helptext record5_164307;


	--output:


	CREATE procedure record5_164307 @RollNo int,@Subject1 int,@Subject2 int,@Subject3 int,@Subject4 int,@Subject5 int,@Total int

   AS

   BEGIN

     insert into record5_164307  values (@RollNo,@Subject1,@Subject2,@Subject3,@Subject4,@Subject5,@Total);

   END
	

